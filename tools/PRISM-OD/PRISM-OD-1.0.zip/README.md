# About
PRISM-OD is a tool for verifying secure information flow (observational determinism) of concurrent probabilistic programs. It takes as input a program written in the [PRISM language](http://www.prismmodelchecker.org/manual/ThePRISMLanguage/Introduction) and analyzes it to check whether there is an information flow violation or not.

The tool is built upon the [PRISM model checker](http://www.prismmodelchecker.org/). PRISM compiles a program written in the PRISM language, builds a discrete-time Markov chain model of the program and stores it using BDDs (Binary Decision Diagrams) and MTBDDs (Multi-Terminal Binary Decision Diagrams). PRISM-OD uses these data structures to extract the set of reachable states and also create a sparse matrix containing the transitions. It then employs two depth-first path exploration algorithms to find all traces of the program and check whether observational determinism holds or not.

# Installation
./install.sh

# Example Usage
bin/prism -od examples/Dining-Crypto/dining-crypto-N3.pm


# People
The people currently working on the tool are:

* [Ali A. Noroozi](https://alianoroozi.github.io), currently a Ph.D. student at [University of Tabriz](http://tabrizu.ac.ir/en) and lead developer of the project,

* [Jaber Karimpour](http://simap.tabrizu.ac.ir/cv/karimpour/?lang=en-gb), an associate professor at University of Tabriz and supervisor of the project,

* [Ayaz Isazadeh](http://isazadeh.net/ayaz), a professor at University of Tabriz and supervisor of the project.
